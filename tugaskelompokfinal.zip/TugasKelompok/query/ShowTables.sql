
SELECT * FROM [dbo].[Akun]
SELECT * FROM [dbo].[InfoAkun]
SELECT * FROM [dbo].[Paket]
SELECT * FROM [dbo].[Transaksi]
SELECT * FROM [dbo].[UserInfo]